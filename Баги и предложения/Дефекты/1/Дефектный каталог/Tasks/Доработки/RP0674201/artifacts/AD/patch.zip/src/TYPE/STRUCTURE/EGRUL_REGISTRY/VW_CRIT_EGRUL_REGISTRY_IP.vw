class EGRUL_REGISTRY;

@name('Выписки ЕГРИП')
view VW_CRIT_EGRUL_REGISTRY_IP {
pragma include(::[EGRUL_REGISTRY].[LIB]);

type main is
select x(
	x							: REG_ID
	, x.[INN]					: INN
	, x.[OGRN]					: OGRN
	, x.[OGRN_DATE]				: OGRN_DATE
	, x.[IP_TYPE_CODE]			: IP_TYPE_CODE
	, f.F_CODE					: F_CODE

	, '{' || coalesce(to_char(xr.CNT), '...') || '}'	: SYNC_RECS
	, xr.LAST_STATUS									: SYNC_STATUS
	, xss.[STATUS_NAME]									: SYNC_STATUS_NAME
	, x.[REG_LAST_UPD] 									: REG_LAST_UPD
	, case when exists (&SAME_CLIENT_SELECT(co_, 1, x.[OGRN], x.[INN])) then '(***)' else '(...)' end: CLIENT

	, replace(ip.[LONG_NAME], '#', ' ')	: LONG_NAME
	, replace(ip.[I_NAME], '#', ' ')	: I_NAME
	, g.[VALUE]					: GENDER
	, st.[STATUS_CODE]			: STATUS_CODE
	, st.[STATUS_NAME]			: STATUS_NAME
	, st.[STATUS_DATE]			: STATUS_DATE
	, translate(x.[ADDRESS], ';=', ', '): ADDRESS_STR
	, x.[EMAIL]					: EMAIL
	, case when ip.[COUNTRY_CODE] = '0' then 'Без гражданства' else c.[NAME] end: COUNTRY
	, x.[TAX_INSP].[ORG_CODE]	: TAX_INSP_CODE
	, x.[TAX_INSP].[ORG_NAME]	: TAX_INSP_NAME
	, x.[TAX_INSP].[REG_DATE]	: TAX_INSP_DATE
	, x.[REG_ORG].[ORG_CODE]	: REG_ORG_CODE
	, x.[REG_ORG].[ORG_NAME]	: REG_ORG_NAME
	, x.[REG_ORG].[ORG_ADDRESS]	: REG_ORG_ADDRESS
	, x.[OBR_UL].[ORG_NAME]		: OBR_UL_NAME
	, x.[OBR_UL].[REG_DATE]		: OBR_UL_DATE
	, x.[OBR_UL].[REG_NUM]		: OBR_UL_NUM
	, farm.[INN]				: OBR_FARM_INN
	, farm.[OGRN]				: OBR_FARM_OGRN
	, farm.[LONG_NAME]			: OBR_FARM_NAME
	-- ПФ
	, x.[PF_REG].[ORG_CODE]		: PF_ORG_CODE
	, x.[PF_REG].[ORG_NAME]		: PF_ORG_NAME
	, x.[PF_REG].[REG_NUM]		: PF_REG_NUM
	, x.[PF_REG].[REG_DATE]		: PF_REG_DATE
	, x.[PF_REG].[REG_DATE_UN]	: PF_REG_DATE_UN
	-- ФСС
	, x.[FSS_REG].[ORG_CODE]	: FSS_REG_CODE
	, x.[FSS_REG].[ORG_NAME]	: FSS_REG_NAME
	, x.[FSS_REG].[REG_NUM]		: FSS_REG_NUM
	, x.[FSS_REG].[REG_DATE]	: FSS_REG_DATE
	, x.[FSS_REG].[REG_DATE_END]: FSS_REG_DATE_END
	, x.[FSS_REG].[REG_DATE_UN]	: FSS_REG_DATE_UN
	-- Сведения о прекращении деятельности в качестве ИП или о прекращении КФХ 
	, x.[END_UL_CODE]			: END_UL_CODE
	, x.[END_UL_NAME]			: END_UL_NAME
	, x.[END_UL].[REG_DATE]		: END_UL_DATE
	-- Сведения о юридическом лице, созданном на базе крестьянского (фермерского) хозяйства
	, n_ul.[INN]				: NEW_UL_INN
	, n_ul.[OGRN]				: NEW_UL_OGRN
	, n_ul.[LONG_NAME]			: NEW_UL_NAME
	, (select l('{' || to_char(count(1)) || '}') in ::[EGRUL_LIC] where l.[REG_REF] = x )	: LIC
	, (select y('{' || to_char(count(1)) || '}') in ::[EGRUL_OKVED] where y.[REG_REF] = x )	: ALL_OKVED
	, case when x.[EXCL_AUTO_SYNC] = true then 'Да'	end	: EXCL_AUTO_SYNC
	, x.[MSG_REF]										: REQ_REF
	, x.[TIME_UPD]										: TIME_UPD
)
in ::[EGRUL_REGISTRY]
	-- Доп. информация о ФЛ
	left outer join (::[EGRUL_REG_STRUCT]: ip) on x = ip.[REG_REF] and ip.[KIND] = 'IP'
		-- Пол
		left outer join (::[SEX]: g) on ip.[GENDER] = g.[CODE]
		-- Страна
		left outer join (::[COUNTRY]: c) on ip.[COUNTRY_CODE] = c.[CODE]
	-- Новое ЮЛ
	left outer join (::[EGRUL_REG_STRUCT]: n_ul) on x = n_UL.[REG_REF] and n_UL.[KIND] = 'N_UL'
	-- Информация о фермерском хозяйстве
	left outer join (::[EGRUL_REG_STRUCT]: farm) on x = farm.[REG_REF] and farm.[KIND] = 'FARM'
	-- Статус
	left outer join (::[EGRUL_UL_STATE]: st) on x = st.[REG_REF]
	left outer join (
		select f(f.F_ID: F_ID, f.F_REF: F_REF, f.F_CODE: F_CODE)
		in
		(
			select t('1': F_ID, t.F_REF: F_REF, t.F_CODE: F_CODE) -- ИП
			in (
				select ff(ff : F_REF, ff.[SHORT_NAME] : F_CODE)
				in ::[FORM_PROPERTY]
				where ff.[CODE] = '50102'
				order by ff.[BEGIN_DATE], ff.[END_DATE]
				)
			union all
			select t('2': F_ID, t.F_REF: F_REF, t.F_CODE: F_CODE) -- КХ
			in (
				select ff(ff : F_REF, ff.[SHORT_NAME] : F_CODE)
				in ::[FORM_PROPERTY]
				where ff.[CODE] = '15300'
				order by ff.[BEGIN_DATE], ff.[END_DATE]
				)
			union all
			select t('3': F_ID, t.F_REF: F_REF, t.F_CODE: F_CODE) -- глава КФХ
			in (
				select ff(ff : F_REF, ff.[SHORT_NAME] : F_CODE)
				in ::[FORM_PROPERTY]
				where ff.[CODE] = '50101'
				order by ff.[BEGIN_DATE], ff.[END_DATE]
				)
			fetch 1
			)
		) on x.[IP_TYPE_CODE] = f.F_ID 
	left outer join (
		select xr(xr.reg_ref : REG_REF, min(s.[STATUS]) : LAST_STATUS, xr.cnt : CNT)
		in (
			select a(a.[REG_REF] : reg_ref, count(1) : cnt, max(coalesce(a.[MODIFIED], to_date('4012-12-31', 'yyyy-mm-dd'))) : modified)
			in ::[EGRUL_SYNC_REC]
			group by a.[REG_REF]
		)
		join (::[EGRUL_SYNC_REC] : s)
			on (s.[REG_REF] = xr.reg_ref
			) and (s.[MODIFIED] = xr.modified
				or xr.modified =to_date('4012-12-31', 'yyyy-mm-dd')
			)
		group by xr.reg_ref, xr.cnt
		) on x = xr.REG_REF
	left outer join (::[EGRUL_SYNC_STAT]: xss) on xr.LAST_STATUS%id = xss%id
where x.[ITEM_TYPE] = 2
order by x.[LONG_NAME];
}