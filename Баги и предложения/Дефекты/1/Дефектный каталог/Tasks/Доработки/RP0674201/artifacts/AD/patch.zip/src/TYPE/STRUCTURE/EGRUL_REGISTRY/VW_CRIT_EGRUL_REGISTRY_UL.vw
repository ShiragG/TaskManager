class EGRUL_REGISTRY;

@name('Выписки ЕГРЮЛ')
view VW_CRIT_EGRUL_REGISTRY_UL {
pragma include(::[EGRUL_REGISTRY].[LIB]);

type main is
select x(
	x							: REG_ID
	, x.[INN]					: INN
	, x.[KPP]					: KPP
	, x.[OGRN]					: OGRN
	, x.[OGRN_DATE]				: OGRN_DATE

	, '{' || coalesce(to_char(xr.CNT), '...') || '}'	: SYNC_RECS
	, xr.LAST_STATUS									: SYNC_STATUS
	, xss.[STATUS_NAME]									: SYNC_STATUS_NAME
	, x.[REG_LAST_UPD]									: REG_LAST_UPD
	, case when exists (&SAME_CLIENT_SELECT(co_, 1, x.[OGRN], x.[INN])) then '(***)' else '(...)' end: CLIENT

	, x.[NAME]					: NAME
	, x.[LONG_NAME]				: LONG_NAME

	, case when x.[OPF_CODE] like '#%' then 'КОПФ '||replace(x.[OPF_CODE], '#') else x.[OPF_CODE] end: OPF_CODE
	, (select fp(fp.[NAME]) in ::[FORM_PROPERTY] where x.[OPF_CODE] = fp.[CODE] fetch 1): OPF_NAME
	, (select y('{' || to_char(count(1)) || '}') in ::[EGRUL_UL_STATE] where y.[REG_REF] = x): STATUS_ARR
	, translate(x.[ADDRESS], ';=', ', ')	: ADDRESS_STR
	, (select y('{' || to_char(count(1)) || '}') in ::[EGRUL_INV_INFO] where y.[REG_REF] = x and y.[KIND] = 'ADDR'): INV_ADDR
	, x.[EMAIL] 				: EMAIL
	, (select xc('{' || to_char(count(1)) || '}') in ::[EGRUL_REG_STRUCT] where xc.[REG_REF] = x and xc.[KIND] = 'CTRL' and xc.[STRUCT_REF] is null)	: CONTROL_ARR
	, (select xp('{' || to_char(count(1)) || '}') in ::[EGRUL_REG_STRUCT] where xp.[REG_REF] = x and xp.[KIND] = 'PERS' and xp.[STRUCT_REF] is null )	: EMPLOYEE_ARR
	, x.[AUTH_CAPITAL]			: AUTH_CAPITAL
	, x.[PART]					: PART
	, x.[PART_SUMMA]			: PART_SUMMA
	, x.[REDUCE_CAPITAL] 		: REDUCE_CAPITAL
	, x.[REDUCE_CAP_DATE] 		: REDUCE_CAP_DATE 
	
	, (select f('{' || to_char(count(1)) || '}') in ::[EGRUL_REG_STRUCT] where f.[REG_REF] = x and f.[KIND] = 'FOUN' )	: FOUNDERS
	, x.[TAX_INSP].[ORG_CODE]	: TAX_INSP_CODE
	, x.[TAX_INSP].[ORG_NAME]	: TAX_INSP_NAME
	, x.[TAX_INSP].[REG_DATE] 	: TAX_INSP_DATE
	
	, x.[REG_ORG].[ORG_CODE]	: REG_ORG_CODE
	, x.[REG_ORG].[ORG_NAME]	: REG_ORG_NAME
	, x.[REG_ORG].[ORG_ADDRESS] : REG_ORG_ADDRESS
	, x.[OBR_UL].[ORG_NAME]		: OBR_UL_NAME
	, x.[OBR_UL].[REG_DATE]		: OBR_UL_DATE
	, x.[OBR_UL].[REG_NUM]		: OBR_UL_NUM
	, x.[OBR_UL].[ID_CODE_UL]	: OBR_UL_ID_CODE_UL
	-- ПФ
	, x.[PF_REG].[ORG_CODE]		: PF_ORG_CODE
	, x.[PF_REG].[ORG_NAME]		: PF_ORG_NAME
	, x.[PF_REG].[REG_NUM]		: PF_REG_NUM
	, x.[PF_REG].[REG_DATE]		: PF_REG_DATE
	, x.[PF_REG].[REG_DATE_UN]	: PF_REG_DATE_UN
	-- ФСС
	, x.[FSS_REG].[ORG_CODE]	: FSS_REG_CODE
	, x.[FSS_REG].[ORG_NAME]	: FSS_REG_NAME
	, x.[FSS_REG].[REG_NUM]		: FSS_REG_NUM
	, x.[FSS_REG].[REG_DATE]	: FSS_REG_DATE
	, x.[FSS_REG].[REG_DATE_UN]	: FSS_REG_DATE_UN
	-- Сведения о решении о предстоящем исключении недействующего ЮЛ из ЕГРЮЛ и его публикации
	, x.[END_UL_CODE]			: END_UL_CODE
	, x.[END_UL_NAME]			: END_UL_NAME
	, x.[END_UL].[REG_DATE]		: END_UL_DATE
	, x.[END_UL].[ORG_CODE]		: END_UL_ORG_CODE
	, x.[END_UL].[ORG_NAME]		: END_UL_ORG_NAME

	, x.[EXCL_DECIS] 			: EXCL_DECIS
	, x.[EXCL_NUM] 				: EXCL_NUM  
	, x.[EXCL_PUBLIC] 			: EXCL_PUBLIC 
	, x.[EXCL_JOURNAL] 			: EXCL_JOURNAL
	
	, (select l('{' || to_char(count(1)) || '}') in ::[EGRUL_LIC] where l.[REG_REF] = x )	: LIC
	, (select y('{' || to_char(count(1)) || '}') in ::[EGRUL_OKVED] where y.[REG_REF] = x )	: ALL_OKVED
	, case when x.[EXCL_AUTO_SYNC] = true then 'Да' end		: EXCL_AUTO_SYNC
	, x.[MSG_REF]				: REQ_REF
	, x.[TIME_UPD]				: TIME_UPD
)
in ::[EGRUL_REGISTRY]
left outer join (
	select xr(xr.reg_ref : REG_REF, min(s.[STATUS]) : LAST_STATUS, xr.cnt : CNT)
	in (
		select a(a.[REG_REF] : reg_ref, count(1) : cnt, max(coalesce(a.[MODIFIED], to_date('4012-12-31', 'yyyy-mm-dd'))) : modified)
		in ::[EGRUL_SYNC_REC]
		group by a.[REG_REF]
	)
	join (::[EGRUL_SYNC_REC] : s)
		on (s.[REG_REF] = xr.reg_ref
		) and (s.[MODIFIED] = xr.modified
			or xr.modified =to_date('4012-12-31', 'yyyy-mm-dd')
		)
	group by xr.reg_ref, xr.cnt
) on x = xr.REG_REF
left outer join (::[EGRUL_SYNC_STAT]: xss) on xr.LAST_STATUS%id = xss%id
where x.[ITEM_TYPE] = 1 
order by x.[NAME]
;
}