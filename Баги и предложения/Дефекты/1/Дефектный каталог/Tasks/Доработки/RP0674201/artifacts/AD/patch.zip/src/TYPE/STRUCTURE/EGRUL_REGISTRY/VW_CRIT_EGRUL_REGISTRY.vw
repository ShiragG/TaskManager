class EGRUL_REGISTRY;


@name(' Полный список')
view VW_CRIT_EGRUL_REGISTRY {
pragma include(::[EGRUL_REGISTRY].[LIB]);

type main is
select x(
	x							: REG_ID
	, x.[ITEM_TYPE]				: ITEM_TYPE
	, case x.[ITEM_TYPE]
		when 1 then 'ЕГРЮЛ'
		when 2 then 'ЕГРИП'
	end							: ITEM_TYPE_NAME
	, x.[INN]					: INN
	, x.[OGRN]					: OGRN
	, x.[OGRN_DATE]				: OGRN_DATE

	, '{' || coalesce(to_char(xr.CNT), '...') || '}'	: SYNC_RECS
	, xr.LAST_STATUS									: SYNC_STATUS
	, xss.[STATUS_NAME]									: SYNC_STATUS_NAME
	, case when exists (&SAME_CLIENT_SELECT(co_, 1, x.[OGRN], x.[INN])) then '(***)' else '(...)' end: CLIENT

	, case x.[ITEM_TYPE]
		when 1 then x.[NAME]
		when 2 then ltrim(f.F_CODE || ' ' || replace(ip.[LONG_NAME], '#', ' '), ' ')
	end							: NAME
	, case x.[ITEM_TYPE]
		when 1 then x.[LONG_NAME]
		when 2 then replace(ip.[LONG_NAME], '#', ' ')
	end							: LONG_NAME
	, translate(x.[ADDRESS], ';=', ', ')	: ADDRESS_STR
	, case when x.[EXCL_AUTO_SYNC] = true then 'Да' end		: EXCL_AUTO_SYNC
	, x.[MSG_REF]				: REQ_REF
	, x.[TIME_UPD]				: TIME_UPD
)
in ::[EGRUL_REGISTRY]
	left outer join (::[EGRUL_REG_STRUCT]: ip) on x = ip.[REG_REF] and ip.[KIND] = 'IP'
	left outer join (
		select f(f.F_ID : F_ID, f.F_REF: F_REF, f.F_CODE: F_CODE)
		in (
			select t('1': F_ID, t.F_REF: F_REF, t.F_CODE: F_CODE) -- ИП
			in (
				select ff(ff: F_REF, ff.[SHORT_NAME]: F_CODE)
				in ::[FORM_PROPERTY]
				where ff.[CODE] = '50102'
				order by ff.[BEGIN_DATE], ff.[END_DATE]
				)
			union all
			select t('2': F_ID, t.F_REF: F_REF, t.F_CODE: F_CODE) -- КХ
			in (
				select ff(ff: F_REF, ff.[SHORT_NAME]: F_CODE)
				in ::[FORM_PROPERTY]
				where ff.[CODE] = '15300'
				order by ff.[BEGIN_DATE], ff.[END_DATE]
				)
			union all
			select t('3': F_ID, t.F_REF: F_REF, t.F_CODE: F_CODE) -- глава КФХ
			in (
				select ff(ff: F_REF, ff.[SHORT_NAME]: F_CODE)
				in ::[FORM_PROPERTY]
				where ff.[CODE] = '50101'
				order by ff.[BEGIN_DATE], ff.[END_DATE]
				)
			fetch 1
			)
		) on x.[IP_TYPE_CODE] = f.F_ID
	left outer join (
		select xr(xr.reg_ref : REG_REF, min(s.[STATUS]) : LAST_STATUS, xr.cnt : CNT)
		in (
			select a(a.[REG_REF] : reg_ref, count(1) : cnt, max(coalesce(a.[MODIFIED], to_date('4012-12-31', 'yyyy-mm-dd'))) : modified)
			in ::[EGRUL_SYNC_REC]
			group by a.[REG_REF]
		)
		join (::[EGRUL_SYNC_REC] : s)
			on (s.[REG_REF] = xr.reg_ref
			) and (s.[MODIFIED] = xr.modified
				or xr.modified =to_date('4012-12-31', 'yyyy-mm-dd')
			)
		group by xr.reg_ref, xr.cnt
	) on x = xr.REG_REF
	left outer join (::[EGRUL_SYNC_STAT]: xss) on xr.LAST_STATUS%id = xss%id
order by case x.[ITEM_TYPE] when 1 then x.[NAME] when 2 then x.[LONG_NAME] end 
;
}