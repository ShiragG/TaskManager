class CL_CORP;

@access(use_context:=false)
@name('Полный список для отчетов')
report view VW_RPT_CL_CORP {
type main is
select r
	( r%classname						: C_CLASS_NAME			-- Наименование типа  
	, r.[LONG_NAME]						: C_LONG_NAME			-- Полное наименование
	, r.[KPP]							: C_KPP					-- КПП
	, r.[KPP_ARR]						: C_KPP_ARR				-- Массив "Дополнительные КПП"
	, r.[FORMA_STR]						: C_FORMA_STR			-- Организационно-правовая форма (строкой)
	, r.[FORMA]							: C_FORMA				-- Организационно-правовая форма
	, r.[PS_REF]						: C_ORG_KIND			-- Вид предприятия. Идентификатор (ссылка)  
	, r.[OWNERSHIP]						: C_OWNERSHIP			-- Форма собственности 
	, r.[REGISTER].[GOS_REG_NUM_REC]	: C_REG#EGR_NUM			-- ЕГРЮЛ: Регистрационный номер
	, r.[REGISTER].[DATE_REG]			: C_REG#EGR_DATE		-- ЕГРЮЛ: Дата внесения записи
	, r.[REGISTER].[SER_SERT]			: C_REG#EGR_CERT_SER	-- ЕГРЮЛ: Свидетельство. Серия
	, r.[REGISTER].[NUM_SERT]			: C_REG#EGR_CERT_NUM	-- ЕГРЮЛ: Свидетельство. Номер
	, r.[REGISTER].[REG_BODY]			: C_REG#REG_ORG			-- Регистрирующий орган
	, r.[REGISTER].[CITY]				: C_REG#CITY			-- Населенный пункт.
	, r.[REGISTER].[DISTRICT]			: C_REG#DISTRICT		-- Район.
	, r.[NA_OSNOV]						: C_REG#ACT_ON_BASIS	-- Действует на основании
	, r.[REGISTER].[FOUNDERS]			: C_REG#FOUNDERS		-- Учредители
	, r.[REGISTER].[DECLARE_UF]			: C_REG#UF_DECLARED		-- Уставной фонд. Объявленный
	, r.[REGISTER].[DECLARE_UF_CUR]		: C_REG#UF_DECLARED_CUR	-- Уставной фонд. Объявленный. Валюта
	, r.[REGISTER].[PAID_UF]			: C_REG#UF_PAID			-- Уставной фонд. Оплаченный
	, r.[REGISTER].[PAID_UF_CUR]		: C_REG#UF_PAID_CUR		-- Уставной фонд. Оплаченный. Валюта
	, r.[REGISTER].[FOREIGN_PART]		: C_REG#UF_FOREIGN_PART	-- Уставной фонд. Доля участия иностранного капитала в уставном фонде (%)
	, r.[REGISTER].[NUM_REESTR]			: C_REG#ALT_NUM			-- Регистрационный номер
	, r.[REGISTER].[DATE_REESTR]		: C_REG#ALT_DATE		-- Дата регистрации
	, r.[REGISTER].[REGISTRAR]			: C_REG#ALT_REG_ORG_NAME-- Регистрирующий орган
	, r.[REGISTER].[REG_PLACE]			: C_REG#ALT_REG_PLACE	-- Место регистрации
	, r.[REGISTER].[ID_CODE_UL]			: C_REG#ALT_ID_CODE		-- Идентификационный код ЮЛ
	, r.[REGISTER].[MAIN_ACC]			: C_REG#MAIN_ACC		-- Основной расчетный счет
	, r.[REGISTER].[BANK]				: C_REG#BANK			-- Банк
	, r.[REGISTER].[BANK].[NAME]		: C_REG#BANK_NAME		-- Наименование банка
	, r.[KIO]							: C_KIO
	, r.[OFFSHORE]						: C_OFFSHORE			-- Офшорная зона
	, r.[OKVED_IN_PERIOD]				: C_OKVEDS				-- Массив "Виды деятельности" (идентификатор)
	, r.[ALL_BOSS]						: C_EMPLOYEES			-- Массив "Должностные лица" (идентификатор)
	, r.[LICENCES]						: C_LICENSES			-- Массив "Лицензии клиента" (идентификатор)
	,	(select c(c.[OPER_CONTROL])
			in ::[CL_INFO_REQ]
			where c.[CLIENT] = r
			fetch 1
		)								: C_OPER_CONTROL		-- Массив "Органы управления" (идентификатор)
	)
	in ::[CL_CORP]
;
}