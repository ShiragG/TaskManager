class SOC_FOUNDS;

@access(check:='none')
@name('Полный список')
view VW_CRIT_SOC_FOUNDS {
type main is
select A1(
  A1.[FOUND]->(true, ::[FUNDS])[TYPES]->(true)[CODE] : C_CODE,
  A1.[FOUND_NUM] : C_FOUND_NUM,
  A1.[DATE_REG] : C_DATE_REG,
  A1.[REG_DATE_END] : C_REG_DATE_END,
  A1.[REG_DATE_UN] : C_REG_DATE_UN,
  A1.[FOUND]->(true, ::[FUNDS])[CLIENTS]->(true)[NAME] : C_NAME,
  A1.[FOUND]->(true, ::[FUNDS])[TYPES]->(true)[NAME] : C_NAME_1,
  ::[RUNTIME].[VIEWFUN].GETADDRESS(A1.[FOUND]->(true)[CLIENTS],'ALL') : C_CLIENTS,
  (select p(cp.[NAME]) in (::[PERSONS_POS]:p), (::[CL_CORP] all :c), (::[CLIENT] all :cp) all where c%id = A1.[FOUND]->(true)[CLIENTS] and p%collection = c.[ALL_BOSS] and p.[FASE] is not null and p.[CHIEF] = '1' and p.[FASE] = cp%id fetch 1) : C_CLIENTS_1
) in ::[SOC_FOUNDS] all;
}