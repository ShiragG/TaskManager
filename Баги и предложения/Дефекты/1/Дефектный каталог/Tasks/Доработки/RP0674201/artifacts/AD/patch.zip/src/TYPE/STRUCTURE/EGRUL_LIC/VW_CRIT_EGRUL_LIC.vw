class EGRUL_LIC;

@name('Полный список')
view VW_CRIT_EGRUL_LIC {
type main is
		select lic(
			lic.[REG_REF] : REG_REF,
			lic.[NUM_LIC] : NUM_LIC,
			lic.[DATE_BEGIN] : DATE_BEGIN,
			lic.[DATE_END] : DATE_END,
			lic.[ORG_LIC] : ORG_LIC,
			lic.[LIST_TYPES] : LIST_TYPES,
			lic.[DATE_STOP_LIC] : DATE_STOP_LIC,
			lic.[ORG_STOP_LIC] : ORG_STOP_LIC,
			lic.[NUM_ERUL] : NUM_ERUL
		)
		in ::[EGRUL_LIC];
}